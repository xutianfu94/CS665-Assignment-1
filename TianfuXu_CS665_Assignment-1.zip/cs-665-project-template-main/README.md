| CS-665       | Software Design & Patterns |
|--------------|----------------------------|
| Name         | Tim Xu                     |
| Date         | 09/20/2023                 |
| Course       | Fall 2023                  |
| Assignment # | 1                          |

# GitHub Repository Link:
https://github.com/{YOUR_USERNAME}/cs-665-assignment-{ASSIGNMENT_NUMBER}

# Beverage Vending Machine

## Overview
This project is an implementation of a beverage vending machine in Java. The vending machine allows users to select beverages, add condiments, calculate the total price, and complete the purchase. This README.md file provides an overview of the project and documents important aspects of its implementation.

## Table of Contents
* Assumptions
* Flexibility
* Simplicity and Understandability
* Avoiding Duplicated Code
* Design Patterns
* How to Compile and Run

## Assumptions

Below are our assumptions related to the project:


Assumption 1: The vending machine operates with a predefined set of beverages and condiments.
Assumption 2: Users can select a beverage, add condiments, and complete the purchase.
Assumption 3: Condiment units and prices are predetermined.
Assumption 4: Prices for beverages and condiments do not change during operation.
Assumption 5: The vending machine accepts user input through the console.
Assumption 6: Vending Machine Processess a single order at a time.

## Flexibility
1. Adding New Drink Types
Our implementation is designed to be flexible in terms of adding new drink types. To add a new drink type, we can 
    1. Create a new Java class for the specific drink type by extending the Beverage class. This new class will then allow to define the unique properties and behavior of the new drink type.
    2. In the VendingMachineFactory class, simply add an instance of your new drink type to the vending machine using the addBeverage method.

2. Removing Drink Types:
Removing a drink type would involve updating the VendingMachineFactory class to exclude references to the removed drink type. You can simply remove the line of code that adds that specific drink type to the vending machine. Additionally, you may need to update any related logic that might be affected by the removal of the drink type.

## Simplicity and Understandability 

Our implementation prioritizes simplicity and understandability. Here's how we achieved this:

* Clear Separation of Concerns: The code is organized into separate classes for beverages, condiments, and the vending machine. This separation makes the codebase easier to navigate and understand.
* Descriptive Naming: We use descriptive variable and method names to enhance code readability.
* Minimal Complexity: We avoid unnecessary complexity, favoring straightforward solutions.

## Avoiding Duplicated Code
We have minimized code duplication by:
1. Using object-oriented principles: Inheritance and encapsulation are employed to promote code reuse.
2. Defining common behavior: Common functionalities are implemented in base classes (e.g., Beverage and Condiment), reducing redundancy.
3. Separating concerns: Each class has a clear and distinct responsibility, reducing the likelihood of duplicated code.

## Design Patterns
In this project, we have used the Factory Method pattern to create instances of the vending machine and drink types. This pattern provides a way to create objects without specifying the exact class of object that will be created. It enhances flexibility and decouples the client code from concrete implementations.

## Compile and Run
To compile and run the project, follow these steps:

1. Clone the project repository to your local machine.

2. Navigate to the project directory.

3. Open a terminal or command prompt.

4. Compile the project using Maven by running the following command:
```bash
mvn clean compile
```
5. Once the compilation is successful, run the project:

```bash
mvn exec:java -Dexec.mainClass="edu.bu.met.cs665.Main"
```

## JUnit Tests
JUnit is a popular testing framework for Java. JUnit tests are automated tests that are written to verify that the behavior of a piece of code is as expected.


To run the test cases, run the below command:
 ```bash
mvn clean test
```