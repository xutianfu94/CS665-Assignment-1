package edu.bu.met.cs665;

public class Beverage {
    private String name;
    private double basePrice;
    private int maxUnits;

    public Beverage(String name, double basePrice, int maxUnits) {
        this.name = name;
        this.basePrice = basePrice;
        this.maxUnits = maxUnits;
    }

    // Getters for name, basePrice, maxMilkUnits, and maxSugarUnits

    public String getDescription() {
        return "A delicious " + name + " beverage.";
    }

    public String getName() {
        return name;
    }

    public double getBasePrice() {
        return basePrice;
    }

    public int getMaxUnits() {
        return maxUnits;
    }

}
