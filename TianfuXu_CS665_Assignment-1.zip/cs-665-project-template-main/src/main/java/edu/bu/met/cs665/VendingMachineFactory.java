package edu.bu.met.cs665;


public class VendingMachineFactory {
    public static VendingMachine createVendingMachine() {
        VendingMachine vendingMachine = new VendingMachine();

        // Add beverages with basePrice and maxUnits  as per requirement
        vendingMachine.addBeverage(new Beverage("Espresso", 2, 3));
        vendingMachine.addBeverage(new Beverage("Americano", 2, 3));
        vendingMachine.addBeverage(new Beverage("Latte Macchiato", 2, 3));

        // Add tea beverages
        vendingMachine.addBeverage(new Beverage("Black Tea", 2, 3));
        vendingMachine.addBeverage(new Beverage("Green Tea", 2, 3));
        vendingMachine.addBeverage(new Beverage("Yellow Tea", 2, 3));


        // Add condiments
        vendingMachine.addCondiment(new Condiment("Milk", 0.5));
        vendingMachine.addCondiment(new Condiment("Sugar", 0.5));

        return vendingMachine;
    }
}
