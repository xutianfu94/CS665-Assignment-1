/**
 * Name: FIRST_NAME LAST_NAME
 * Course: CS-665 Software Designs & Patterns
 * Date: MM/DD/YYYY
 * File Name: Main.java
 * Description: Write a description for this class
 */

package edu.bu.met.cs665;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Create a vending machine with predefined beverages and condiments
        VendingMachine vendingMachine = VendingMachineFactory.createVendingMachine();

        // Initialize the scanner for user input
        Scanner scanner = new Scanner(System.in);

        // Create a menu handler to manage user interactions
        MenuHandler menuHandler = new MenuHandler(vendingMachine, scanner);

        // Display a welcome message
        //menuHandler.displayWelcomeMessage();

        // Start the vending machine and handle user interactions
        menuHandler.run();

        // Close the scanner
        scanner.close();
    }
}

