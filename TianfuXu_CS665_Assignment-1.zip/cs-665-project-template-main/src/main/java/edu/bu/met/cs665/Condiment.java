package edu.bu.met.cs665;


public class Condiment {
    private String name;
    private double price;

    public Condiment(String name, double price) {
        this.name = name;
        this.price = price;
    }

    // Getter for the name of the condiment
    public String getName() {
        return name;
    }

    // Getter for the price of the condiment
    public double getPrice() {
        return price;
    }
}
