package edu.bu.met.cs665;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VendingMachine {
    private List<Beverage> beverages;
    private List<Condiment> condiments;
    private Map<Beverage, Map<Condiment, Integer>> beverageCondiments;

    public VendingMachine() {
        beverages = new ArrayList<>();
        condiments = new ArrayList<>();
        beverageCondiments = new HashMap<>();
    }

    // Add a new beverage to the vending machine
    public void addBeverage(Beverage beverage) {
        beverages.add(beverage);
        beverageCondiments.put(beverage, new HashMap<>());
    }

    // Add a new condiment to the vending machine
    public void addCondiment(Condiment condiment) {
        condiments.add(condiment);
    }

    // Get the list of available beverages
    public List<Beverage> getAvailableBeverages() {
        return beverages;
    }

    // Get the list of available condiments
    public List<Condiment> getAvailableCondiments() {
        return condiments;
    }

    // Add a condiment to a specific beverage
    public boolean addCondimentToBeverage(Beverage beverage, Condiment condiment, int units) {
        if (beverageCondiments.containsKey(beverage)) {
            Map<Condiment, Integer> beverageCondimentMap = beverageCondiments.get(beverage);
            beverageCondimentMap.put(condiment, units);
            return true;
        }
        return false;
    }

    // Calculate the price of a beverage including condiments
    public double calculatePrice(Beverage beverage) {
        double totalPrice = beverage.getBasePrice();
        Map<Condiment, Integer> beverageCondimentMap = beverageCondiments.get(beverage);

        for (Map.Entry<Condiment, Integer> entry : beverageCondimentMap.entrySet()) {
            totalPrice += entry.getKey().getPrice() * entry.getValue();
        }

        return totalPrice;
    }
}
