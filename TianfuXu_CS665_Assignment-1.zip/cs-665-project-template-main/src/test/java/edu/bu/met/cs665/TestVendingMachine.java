package edu.bu.met.cs665;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Scanner;

public class TestVendingMachine {

    private VendingMachine vendingMachine;
    private MenuHandler menuHandler;
    private Scanner scanner = new Scanner(System.in);

    // public TestVendingMachine(){

    // }

    @Before
    public void setUp() {
        vendingMachine = VendingMachineFactory.createVendingMachine();
        menuHandler = new MenuHandler(vendingMachine, new Scanner(System.in));
    }

    @Test
    public void testExitFromMenu() {
        String input = "0\n"; // Simulate user selecting to exit

        MenuHandler mH = new MenuHandler(vendingMachine, new Scanner(input));
        // Start the vending machine and handle user interactions
        // Assertions
        assertEquals(0, mH.displayMenu()); // Check if the menu loop exits
    }

    @Test
    public void testInvalidInputThenSelectingCorrect() {
        String input = "invalid\n1\n0\n"; // Simulate invalid input first, then select a beverage, and exit
        MenuHandler mH = new MenuHandler(vendingMachine, new Scanner(input));
        // Assertions
        assertEquals(1, mH.displayMenu()); // Check if the menu loop exits
    }

    @Test
    public void testSelectInvalidBeverageAndExit() {
        String input = "59\n0\n"; // Simulate invalid input first, then select exit
        MenuHandler mH = new MenuHandler(vendingMachine, new Scanner(input));
        // Assertions
        assertEquals(0, mH.displayMenu()); // Check if the menu loop exits
    }

    // Simulate user selecting Espresso, adding 1 unit of Milk, 2 units of Sugar, and finishing
    @Test
    public void testSelectBeverageAndAddCondiments() {
        String input = "1\n1\n1\n2\n2\n0\n"; 
        MenuHandler mH = new MenuHandler(vendingMachine, new Scanner(input));
        // Assertions
        assertEquals(1, mH.displayMenu()); // Check if the menu loop exits
        assertEquals(3.5, mH.totalPrice, 0.01); // Check if the totalPrice Calculated Correctly
        
    }

    // Simulate user inputing out of range condiments units
    @Test
    public void testOutOfRangeCondimentUnits() {
        String input = "1\n1\n7\n1\n2\n0\n"; 
        MenuHandler mH = new MenuHandler(vendingMachine, new Scanner(input));
        // Assertions
        assertEquals(1, mH.displayMenu()); // Check if the menu loop exits
        assertEquals(3, mH.totalPrice, 0.01); // Check if the totalPrice Calculated Correctly
        
    }

    // Simulate user updating the condiments units decreasing from 3 to 2 units of sugar
    @Test
    public void testUpdatingCondimentUnits() {
        String input = "1\n2\n3\n2\n2\n0\n"; 
        MenuHandler mH = new MenuHandler(vendingMachine, new Scanner(input));
        // Assertions
        assertEquals(1, mH.displayMenu()); // Check if the menu loop exits
        assertEquals(3, mH.totalPrice, 0.01); // Check if the totalPrice Calculated Correctly
        
    }

}
