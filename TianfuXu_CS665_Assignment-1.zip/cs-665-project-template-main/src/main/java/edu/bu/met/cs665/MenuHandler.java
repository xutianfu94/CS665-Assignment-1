package edu.bu.met.cs665;

import java.util.List;
import java.util.Scanner;

public class MenuHandler {
    private VendingMachine vendingMachine;
    private Scanner scanner;
    public String user_beverage;
    public int numMilkUnits = 0;
    public int numSugarUnits = 0;
    public double totalPrice;

    public MenuHandler(VendingMachine vendingMachine, Scanner scanner) {
        this.vendingMachine = vendingMachine;
        this.scanner = scanner;
    }

    // Display a welcome message to the user
    public void displayWelcomeMessage() {
        System.out.println("\n\nWelcome to the Beverage Vending Machine!");
    }

    // Display the available beverage options and handle user interactions
    public int displayMenu() {
        List<Beverage> availableBeverages = vendingMachine.getAvailableBeverages();
        List<Condiment> availableCondiments = vendingMachine.getAvailableCondiments();
        System.out.println("\n====================================");
        System.out.println("\tAvailable Beverages");
        System.out.println("====================================");
        for (int i = 0; i < availableBeverages.size(); i++) {
            System.out.println((i + 1) + ". " + availableBeverages.get(i).getName());
        }

        while (true) {
            //System.out.println("Select 0 to Exit");
            System.out.print("Select a beverage (1-" + availableBeverages.size() + ") or Select 0 to Exit: ");
            int beverageChoice;
            try {
                beverageChoice = scanner.nextInt();
            } catch (java.util.InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine(); // Clear the invalid input
                continue;
            }

            if (beverageChoice < 0 || beverageChoice > availableBeverages.size()) {
                System.out.println("Invalid choice. Please select a valid beverage or 0 to exit.");
                continue;
            }

            if (beverageChoice == 0) {
                System.out.println("Exiting the program.");
                return 0; // Exit the method if 0 is selected
            }

            Beverage selectedBeverage = availableBeverages.get(beverageChoice - 1);
            user_beverage = selectedBeverage.getName();
            System.out.println("You've selected: " + selectedBeverage.getName());

            // Allow the user to select and add condiments
            selectAndAddCondiments(selectedBeverage);

            // Calculate and display the total price
            totalPrice = vendingMachine.calculatePrice(selectedBeverage);
            System.out.println("\nTotal Price: $" + totalPrice);

            // Handle payment (simulated message)
            System.out.println("\nPlease insert cash or use a payment method.");

            // Start the brewing process (simulated message)
            System.out.println("\nBrewing your " + selectedBeverage.getName() + "...");
            System.out.println("Please wait...");

            System.out.println("\nYour " + selectedBeverage.getName() + " is ready!");

            // Clear scanner buffer
            scanner.nextLine();

            return 1; // Exit the loop once a valid selection is made
        }
    }

    // Allow the user to select and add condiments to the selected beverage
    private void selectAndAddCondiments(Beverage beverage) {
        List<Condiment> availableCondiments = vendingMachine.getAvailableCondiments();
        System.out.println("\n====================================");        
        System.out.println("\tAvailable Condiments");
        System.out.println("====================================");

        for (int i = 0; i < availableCondiments.size(); i++) {
            System.out.println((i + 1) + ". " + availableCondiments.get(i).getName());
        }

        while (true) {
            System.out.print("Select a condiment to add (0 to finish): ");
            //int condimentChoice = scanner.nextInt();
            int condimentChoice ;
            try {
                condimentChoice = scanner.nextInt();
            } catch (java.util.InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine(); // Clear the invalid input
                continue;
            }
            if (condimentChoice == 0) {
                break;
            }
            if (condimentChoice < 1 || condimentChoice > availableCondiments.size()) {
                System.out.println("Invalid condiment choice. Please select a valid condiment.");
                continue;
            }
            Condiment selectedCondiment = availableCondiments.get(condimentChoice - 1);

            System.out.print("Enter the number of units to add: ");
            //int units = scanner.nextInt();
            int units;
            try {
                units = scanner.nextInt();
            } catch (java.util.InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine(); // Clear the invalid input
                continue;
            }
            
            if (units < 0) {
                System.out.println("Invalid number of units. Please enter a positive value.");
                continue;
            }

            // Check if the units selected are within the maximum allowed units for the condiment
            if (units > beverage.getMaxUnits()) {
                System.out.println("Invalid number of units. Maximum allowed: " + beverage.getMaxUnits());
                continue;
            }

            // Add the selected condiment and units to the beverage
            if (vendingMachine.addCondimentToBeverage(beverage, selectedCondiment, units)) {
                System.out.println(units + " units of " + selectedCondiment.getName() + " added.");
            } else {
                System.out.println("Failed to add condiment. You've reached the maximum limit.");
            }
        }
    }

    // Run the vending machine menu and interaction loop
    public int run() {
        while (true) {
            displayWelcomeMessage();
            int exit = displayMenu();
            if (exit == 0){
                return 0;
            }
            System.out.print("\n\nDo you want to make another selection? (1 - YES/0 - NO): ");
            //String anotherSelection = scanner.nextLine().trim().toLowerCase();
            int anotherSelection;
            try {
                anotherSelection = scanner.nextInt();
            } catch (java.util.InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine(); // Clear the invalid input
                continue;
            }
            if (anotherSelection == 0) {
                return 0;
            }

        }
    }
}
